#🚨 Don't change the code below 👇
age = input("What is your current age? ")
#🚨 Don't change the code above 👆
#Write your code below this line 👇

consy = 90 - int(age)

print(f"you have {consy*365} days, {consy*52} weeks, and {consy*12} months later")