def greet():
    print("Suck a dickerson")
    print("Cucon Pele")

def greet_with_name(name):
    print(f"Suck a dickerson, {name}")
    print("Cucon Pele")

def greet_with(name, location):
    print(f"Hello, {name}!")
    print(f"Go to pulta que o pariu! ({location}, rs)")

greet()

greet_with_name("Jegson mendes")

greet_with("Jegson", "cu do caralho")

greet_with(location="cu do caralho", name="Jegson")